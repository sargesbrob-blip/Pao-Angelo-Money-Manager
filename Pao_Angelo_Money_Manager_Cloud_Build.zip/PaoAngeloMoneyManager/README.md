# Pao Angelo Money Manager — Native Android starter

## Build an APK
1. Install Android Studio (Ladybug or newer), JDK 17, and Android SDK Platform 35.
2. Extract this ZIP; open the `PaoAngeloMoneyManager` folder in Android Studio.
3. Sync Gradle and install SDK 35 if prompted.
4. Run on an Android phone (USB debugging) or emulator.
5. Build → Build Bundle(s) / APK(s) → Build APK(s).
6. Debug APK: `app/build/outputs/apk/debug/app-debug.apk`.
For a signed release APK: Build → Generate Signed Bundle / APK → APK and create a keystore.

## Included
Compose dashboard, transactions and history, budgets, savings goals, Room persistence, SQLCipher database encryption, encrypted preferences for DB key, Android speech recognizer with en-PH, simple English/Filipino command parsing.

## Prototype limitations
- Voice assistant is a local rule-based parser, not generative AI. Device speech recognition availability and Filipino support vary.
- Initial project has no explicit Room migrations, editing/deletion UI, backups, or cloud sync. Add migrations before shipping; do not use destructive migration for production.
- Keep device lock enabled; never save bank PINs/passwords. Review dependencies and build/test before release.
