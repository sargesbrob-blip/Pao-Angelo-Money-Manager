package com.paoangelo.moneymanager
import android.content.Context
import androidx.room.*
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import net.sqlcipher.database.SQLiteDatabase
import net.sqlcipher.database.SupportFactory
import java.util.UUID
import kotlinx.coroutines.flow.Flow
@Entity data class Tx(@PrimaryKey val id:String=UUID.randomUUID().toString(),val title:String,val cents:Long,val type:String,val category:String,val date:Long=System.currentTimeMillis())
@Entity data class Budget(@PrimaryKey val category:String,val limitCents:Long)
@Entity data class Goal(@PrimaryKey val id:String=UUID.randomUUID().toString(),val title:String,val target:Long,val saved:Long)
@Dao interface Dao {
 @Query("SELECT * FROM Tx ORDER BY date DESC") fun tx():Flow<List<Tx>>
 @Insert suspend fun add(t:Tx)
 @Delete suspend fun delete(t:Tx)
 @Query("SELECT * FROM Budget") fun budgets():Flow<List<Budget>>
 @Insert(onConflict=OnConflictStrategy.REPLACE) suspend fun budget(b:Budget)
 @Query("SELECT * FROM Goal") fun goals():Flow<List<Goal>>
 @Insert(onConflict=OnConflictStrategy.REPLACE) suspend fun goal(g:Goal)
}
@Database(entities=[Tx::class,Budget::class,Goal::class],version=1,exportSchema=false)
abstract class DB:RoomDatabase(){
 abstract fun dao():Dao
 companion object { @Volatile var inst:DB?=null
 fun get(c:Context):DB=inst?: synchronized(this){inst?:build(c).also{inst=it}}
 private fun build(c:Context):DB {
 val master=MasterKey.Builder(c).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build()
 val prefs=EncryptedSharedPreferences.create(c,"pao_secret",master,EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM)
 var secret=prefs.getString("key",null);if(secret==null){secret=UUID.randomUUID().toString()+UUID.randomUUID().toString();prefs.edit().putString("key",secret).apply()}
 return Room.databaseBuilder(c,DB::class.java,"pao.db").openHelperFactory(SupportFactory(SQLiteDatabase.getBytes(secret.toCharArray()))).build()
 }}
}
