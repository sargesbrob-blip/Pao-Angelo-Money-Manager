package com.paoangelo.moneymanager
import android.Manifest
import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.speech.RecognizerIntent
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.foundation.text.KeyboardOptions
import java.text.NumberFormat
import java.util.*
class MainActivity:ComponentActivity(){override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState);setContent{MaterialTheme{Screen()}}}}
class VM(app:android.app.Application):AndroidViewModel(app){
 val d=DB.get(app).dao();val tx=d.tx().stateIn(viewModelScope,SharingStarted.WhileSubscribed(5000),emptyList());val budgets=d.budgets().stateIn(viewModelScope,SharingStarted.WhileSubscribed(5000),emptyList());val goals=d.goals().stateIn(viewModelScope,SharingStarted.WhileSubscribed(5000),emptyList())
 fun add(t:Tx)=viewModelScope.launch{d.add(t)};fun budget(b:Budget)=viewModelScope.launch{d.budget(b)};fun goal(g:Goal)=viewModelScope.launch{d.goal(g)}
 fun voice(s0:String,cb:(String)->Unit){val s=s0.lowercase();val income=listOf("earned","income","salary","sweldo","sahod","kita","natanggap").any{s.contains(it)};val m=Regex("(\\\\d[\\\\d,]*(?:\\\\.\\\\d{1,2})?)").find(s)?.value?.replace(",","")?.toDoubleOrNull();if(m==null||m<=0){cb("Amount not found. Try saying an amount.");return};val cat=when{listOf("food","kain","pagkain","meal").any{s.contains(it)}->"Food";listOf("fare","pamasahe","jeep","bus").any{s.contains(it)}->"Transportation";listOf("bill","kuryente","tubig").any{s.contains(it)}->"Bills";else->"Other"};add(Tx(title=cat,cents=(m*100).toLong(),type=if(income)"INCOME" else "EXPENSE",category=cat));cb("Saved ${if(income)"income" else "expense"} ₱$m for $cat.")}
}
fun php(c:Long)=NumberFormat.getCurrencyInstance(Locale("en","PH")).format(c/100.0)
@Composable fun Screen(vm:VM=viewModel()){
 val tx by vm.tx.collectAsState();val budgets by vm.budgets.collectAsState();val goals by vm.goals.collectAsState();var page by remember{mutableIntStateOf(0)};var dlg by remember{mutableStateOf(false)};var title by remember{mutableStateOf("")};var amt by remember{mutableStateOf("")};var cat by remember{mutableStateOf("Food")};var type by remember{mutableStateOf("EXPENSE")};var voice by remember{mutableStateOf("Try English or Filipino voice commands")}
 val speech=rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()){r->val phrase=r.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull();if(r.resultCode==Activity.RESULT_OK&&phrase!=null)vm.voice(phrase){voice=it}}
 val mic=rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()){ok->if(ok){val i=Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply{putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);putExtra(RecognizerIntent.EXTRA_LANGUAGE,"en-PH")};try{speech.launch(i)}catch(e:Exception){voice="Speech service unavailable"}}}
 val inc=tx.filter{it.type=="INCOME"}.sumOf{it.cents};val exp=tx.filter{it.type=="EXPENSE"}.sumOf{it.cents}
 Scaffold(topBar={TopAppBar(title={Text("Pao Angelo Money Manager")})},floatingActionButton={FloatingActionButton({dlg=true}){Text("+")}},bottomBar={NavigationBar{listOf("Home","History","Goals","Voice").forEachIndexed{i,s->NavigationBarItem(page==i,{page=i},{Text(listOf("⌂","▤","⚑","🎙")[i])},label={Text(s)})}}}){p->
 if(page==3)Column(Modifier.padding(p).padding(20.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){Text("Voice assistant",style=MaterialTheme.typography.headlineSmall);Text(voice);Button({mic.launch(Manifest.permission.RECORD_AUDIO)}){Text("🎙 Speak")};Text("Try: I spent 250 pesos on food");Text("Try: Gumastos ako ng 100 sa pamasahe");Text("Income ${php(inc)} · Expenses ${php(exp)} · Balance ${php(inc-exp)}")}
 else LazyColumn(Modifier.padding(p).padding(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){
 item{Card{Column(Modifier.padding(16.dp)){Text("TOTAL BALANCE");Text(php(inc-exp),style=MaterialTheme.typography.headlineLarge);Text("Income ${php(inc)}   Expenses ${php(exp)}")}}}
 item{Row{Button({dlg=true}){Text("Add transaction")};Spacer(Modifier.width(8.dp));OutlinedButton({page=3}){Text("Voice assistant")}}}
 item{Text("Budgets",style=MaterialTheme.typography.titleMedium)}
 items(budgets){b->Text("${b.category} · ${php(b.limitCents)}")}
 item{Text(if(page==1)"Transaction history" else "Recent transactions",style=MaterialTheme.typography.titleMedium)}
 items(tx){t->Row(Modifier.fillMaxWidth().padding(vertical=8.dp),horizontalArrangement=Arrangement.SpaceBetween){Column{Text(t.title);Text(t.category,style=MaterialTheme.typography.bodySmall)};Text((if(t.type=="INCOME")"+" else "−")+php(t.cents))}}
 item{Text("Savings goals",style=MaterialTheme.typography.titleMedium)};items(goals){g->Text("${g.title} ${php(g.saved)} / ${php(g.target)}")}
 }
 }
 if(dlg)AlertDialog(onDismissRequest={dlg=false},title={Text("Add income / expense")},text={Column{Row{FilterChip(type=="EXPENSE",{type="EXPENSE"},{Text("Expense")});FilterChip(type=="INCOME",{type="INCOME"},{Text("Income")})};OutlinedTextField(title,{title=it},label={Text("Description")});OutlinedTextField(amt,{amt=it},label={Text("Amount PHP")},keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Decimal));OutlinedTextField(cat,{cat=it},label={Text("Category")})}},confirmButton={Button(enabled=title.isNotBlank()&&(amt.toDoubleOrNull()?:0.0)>0,onClick={vm.add(Tx(title=title,cents=(amt.toDouble()*100).toLong(),type=type,category=cat));title="";amt="";dlg=false}){Text("Save")}},dismissButton={TextButton({dlg=false}){Text("Cancel")}})
}
